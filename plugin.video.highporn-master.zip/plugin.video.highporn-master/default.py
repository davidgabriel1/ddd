# -*- coding: utf8 -*-

from path import plugin

if __name__ == '__main__':
    plugin.run()
